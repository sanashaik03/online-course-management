package com.example.onlinecoursemanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineCourseManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(OnlineCourseManagementApplication.class, args);
    }

}
