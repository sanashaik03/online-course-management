package com.example.onlinecoursemanagement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/assignments")
public class AssignmentController {

    @Autowired
    private AssignmentRepository assignmentRepository;

    @Autowired
    private CourseRepository courseRepository;

    // Add a new assignment (Educators Only)
    @PostMapping
    public ResponseEntity<String> addAssignment(@RequestBody Assignment assignment) {
        if (assignment.getCourse() == null || assignment.getCourse().getId() == null) {
            return new ResponseEntity<>("Course information is required", HttpStatus.BAD_REQUEST);
        }

        // Check if course exists
        courseRepository.findById(assignment.getCourse().getId()).ifPresentOrElse(
                course -> {
                    assignment.setCourse(course);
                    assignmentRepository.save(assignment);
                },
                () -> {
                    throw new IllegalArgumentException("Course not found");
                }
        );

        return new ResponseEntity<>("Assignment added successfully", HttpStatus.CREATED);
    }

    // View all assignments for a course
    @GetMapping("/course/{courseId}")
    public ResponseEntity<List<Assignment>> getAssignmentsByCourse(@PathVariable Long courseId) {
        List<Assignment> assignments = assignmentRepository.findByCourseId(courseId);
        return new ResponseEntity<>(assignments, HttpStatus.OK);
    }
}
