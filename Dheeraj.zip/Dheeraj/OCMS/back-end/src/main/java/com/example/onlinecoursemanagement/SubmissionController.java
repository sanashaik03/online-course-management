package com.example.onlinecoursemanagement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/submissions")
public class SubmissionController {

    @Autowired
    private SubmissionRepository submissionRepository;

    @Autowired
    private AssignmentRepository assignmentRepository;

    @Autowired
    private UserRepository userRepository;

    // Submit an assignment (Students Only)
    @PostMapping("/submit")
    public ResponseEntity<String> submitAssignment(@RequestBody Submission submission) {
        if (submission.getStudent() == null || submission.getStudent().getId() == null) {
            return new ResponseEntity<>("Student information is required", HttpStatus.BAD_REQUEST);
        }

        // Check if student exists and validate role
        userRepository.findById(submission.getStudent().getId()).ifPresentOrElse(
                student -> {
                    if (student.getRole() != User.Role.STUDENT) {
                        throw new IllegalArgumentException("User is not a student");
                    }

                    // Validate the assignment
                    assignmentRepository.findById(submission.getAssignment().getId()).ifPresentOrElse(
                            assignment -> {
                                submission.setSubmissionDate(LocalDateTime.now());
                                if (LocalDateTime.now().isAfter(assignment.getDueDate())) {
                                    submission.setStatus(Submission.Status.valueOf("LATE"));
                                } else {
                                    submission.setStatus(Submission.Status.valueOf("SUBMITTED"));
                                }
                                submissionRepository.save(submission);
                            },
                            () -> {
                                throw new IllegalArgumentException("Assignment not found");
                            }
                    );
                },
                () -> {
                    throw new IllegalArgumentException("Student not found");
                }
        );

        return new ResponseEntity<>("Assignment submitted successfully", HttpStatus.CREATED);
    }

    // View submissions for an assignment
    @GetMapping("/assignment/{assignmentId}")
    public ResponseEntity<List<Submission>> getSubmissionsByAssignment(@PathVariable Long assignmentId) {
        List<Submission> submissions = submissionRepository.findByAssignmentId(assignmentId);
        return new ResponseEntity<>(submissions, HttpStatus.OK);
    }

    // Update a submission (Students Only)
    @PutMapping("/update")
    public ResponseEntity<String> updateSubmission(@RequestBody Submission submission) {
        if (submission.getId() == null) {
            return new ResponseEntity<>("Submission ID is required", HttpStatus.BAD_REQUEST);
        }

        submissionRepository.findById(submission.getId()).ifPresentOrElse(
                existingSubmission -> {
                    existingSubmission.setSubmissionDate(LocalDateTime.now()); // Update timestamp
                    existingSubmission.setStatus(Submission.Status.valueOf("UPDATED"));
                    submissionRepository.save(existingSubmission);
                },
                () -> {
                    throw new IllegalArgumentException("Submission not found");
                }
        );

        return new ResponseEntity<>("Submission updated successfully", HttpStatus.OK);
    }
}
