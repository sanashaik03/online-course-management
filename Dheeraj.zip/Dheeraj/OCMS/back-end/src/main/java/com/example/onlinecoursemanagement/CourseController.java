package com.example.onlinecoursemanagement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/courses")
public class CourseController {

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private UserRepository userRepository;

    // Add a new course (Educators Only)
    @PostMapping
    public ResponseEntity<String> addCourse(@RequestBody Course course) {
        if (course.getEducator() == null || course.getEducator().getId() == null) {
            return new ResponseEntity<>("Educator information is required", HttpStatus.BAD_REQUEST);
        }

        // Check if educator exists and validate role
        userRepository.findById(course.getEducator().getId()).ifPresentOrElse(
                educator -> {
                    if (educator.getRole() != User.Role.EDUCATOR) {
                        throw new IllegalArgumentException("User is not an educator");
                    }
                    course.setEducator(educator);
                    courseRepository.save(course);
                },
                () -> {
                    throw new IllegalArgumentException("Educator not found");
                }
        );

        return new ResponseEntity<>("Course added successfully", HttpStatus.CREATED);
    }

    // View all courses
    @GetMapping
    public ResponseEntity<List<Course>> getAllCourses() {
        List<Course> courses = courseRepository.findAll();
        return new ResponseEntity<>(courses, HttpStatus.OK);
    }

    // View courses by educator
    @GetMapping("/educator/{educatorId}")
    public ResponseEntity<List<Course>> getCoursesByEducator(@PathVariable Long educatorId) {
        List<Course> courses = courseRepository.findByEducatorId(educatorId);
        return new ResponseEntity<>(courses, HttpStatus.OK);
    }
}
