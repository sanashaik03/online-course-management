document.getElementById('add-course-form').addEventListener('submit', function (e) {
    e.preventDefault();

    const courseData = {
        title: document.getElementById('title').value,
        description: document.getElementById('description').value,
        educatorId: sessionStorage.getItem('userId'), // Assuming the educator's ID is stored in session
    };

    fetch('http://localhost:8080/api/courses', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(courseData),
    })
        .then(response => {
            if (response.ok) {
                alert('Course added successfully!');
                window.location.href = 'educator-dashboard.html';
            } else {
                alert('Failed to add course. Please try again.');
            }
        })
        .catch(error => {
            console.error('Error adding course:', error);
            alert('An error occurred. Please try again later.');
        });
});
