document.getElementById('signup-form').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent default form submission

    // Get form inputs
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();
    const confirmPassword = document.getElementById('confirm-password').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const role = document.getElementById('role').value.toUpperCase(); // Convert role to uppercase
    const terms = document.getElementById('terms').checked;

    // Validation
    if (!name || !email || !password || !confirmPassword || !phone || !role || !terms) {
        alert('Please fill in all required fields.');
        return false;
    }

    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailPattern.test(email)) {
        alert('Please enter a valid email address.');
        return false;
    }

    if (password.length < 6) {
        alert('Password should be at least 6 characters long.');
        return false;
    }

    if (password !== confirmPassword) {
        alert('Passwords do not match.');
        return false;
    }

    const phonePattern = /^\+91\d{10}$/;
    if (!phonePattern.test(phone)) {
        alert('Please enter a valid phone number starting with +91.');
        return false;
    }

    // Submit data to the backend
    fetch('http://localhost:8080/api/users/signup', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, email, password, phone, role }),
    })
        .then((response) => {
            if (response.ok) {
                return response.json(); // Parse JSON response from the backend
            } else {
                throw new Error('Signup failed');
            }
        })
        .then((data) => {
            alert(data.message); // Show the success message from backend
            window.location.href = 'signin.html'; // Redirect to the sign-in page
        })
        .catch((error) => {
            alert('Error: ' + error.message);
        });

});
