// Logout functionality
document.getElementById('logout-btn').addEventListener('click', function () {
    // Clear user session data
    sessionStorage.clear();

    // Notify the user
    alert('You have been logged out.');

    // Redirect to the Sign In page
    window.location.href = '../signin.html';
});
