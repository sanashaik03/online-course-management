document.addEventListener('DOMContentLoaded', function () {
    const urlParams = new URLSearchParams(window.location.search);
    const courseId = urlParams.get('courseId');

    if (!courseId) {
        alert('Invalid course ID. Redirecting to the dashboard.');
        window.location.href = 'student-dashboard.html';
        return;
    }

    fetch(`http://localhost:8080/api/courses/${courseId}`)
        .then(response => response.json())
        .then(course => {
            document.getElementById('course-title').innerText = course.title;
            document.getElementById('course-description').innerText = course.description;
            document.getElementById('course-image').src = course.image || 'default-image.jpg';
            document.getElementById('educator-name').innerText = `Educator: ${course.educatorName || 'N/A'}`;
        })
        .catch(error => {
            console.error('Error fetching course details:', error);
            alert('Failed to load course details. Please try again later.');
        });
});
