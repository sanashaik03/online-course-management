document.addEventListener('DOMContentLoaded', function () {
    const courseListContainer = document.getElementById('course-list');

    // Fetch courses from backend
    fetch('http://localhost:8080/api/courses')
        .then(response => response.json())
        .then(data => {
            // Populate courses dynamically
            courseListContainer.innerHTML = ''; // Clear existing content
            data.forEach(course => {
                const courseCard = `
                    <div class="course-card">
                        <img src="${course.image || 'default-image.jpg'}" alt="${course.title}">
                        <div class="course-info">
                            <h4>${course.title}</h4>
                            <p>${course.description}</p>
                            <button onclick="goToCourseDetails(${course.id})">View Details</button>
                        </div>
                    </div>
                `;
                courseListContainer.innerHTML += courseCard;
            });
        })
        .catch(error => {
            console.error('Error fetching courses:', error);
            alert('Failed to load courses. Please try again later.');
        });
});

function goToCourseDetails(courseId) {
    window.location.href = `course-details.html?courseId=${courseId}`;
}
