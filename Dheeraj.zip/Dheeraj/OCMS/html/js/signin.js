document.getElementById('signin-form').addEventListener('submit', async function (e) {
    e.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const role = document.getElementById('role').value.toUpperCase(); // Ensure case matches backend
    try {
        const response = await fetch('http://localhost:8080/api/users/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password, role }),
        });

        if (response.ok) {
            const data = await response.json();
            alert(data.message); // Display success message

            // Store user info in session storage for future use
            sessionStorage.setItem('userName', data.name);
            sessionStorage.setItem('userRole', data.role);
            sessionStorage.setItem('userId', data.id);

            // Redirect based on role
            if (data.role === 'STUDENT') {

                window.location.href = '../student-dashboard.html';
            } else if (data.role === 'EDUCATOR') {

                window.location.href = '../educator-dashboard.html';
            } else {
                alert('Invalid role detected.');
            }
        } else {
            const errorData = await response.json();
            alert(errorData.error || 'Invalid email or password.');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Failed to connect to the server.');
    }
});
