-- Educators
INSERT INTO user (name, email, password, role) VALUES 
('Ravi Kumar', 'ravi.kumar@example.com', 'password123', 'EDUCATOR'),
('Meera Sharma', 'meera.sharma@example.com', 'password123', 'EDUCATOR'),
('Ankit Verma', 'ankit.verma@example.com', 'password123', 'EDUCATOR');

-- Students
INSERT INTO user (name, email, password, role) VALUES 
('Aarav Gupta', 'aarav.gupta@example.com', 'password123', 'STUDENT'),
('Ishita Desai', 'ishita.desai@example.com', 'password123', 'STUDENT'),
('Vihaan Patel', 'vihaan.patel@example.com', 'password123', 'STUDENT'),
('Ananya Reddy', 'ananya.reddy@example.com', 'password123', 'STUDENT'),
('Krishna Singh', 'krishna.singh@example.com', 'password123', 'STUDENT');

-- Courses
INSERT INTO course (title, description, educator_id, created_at) VALUES
('C Programming Basics', 'Introduction to C programming.', 1, NOW()),
('Data Structures', 'Learn data structures like arrays and linked lists.', 2, NOW()),
('Database Systems', 'Basics of SQL and database design.', 3, NOW()),
('Web Development', 'Learn to build web applications.', 1, NOW()),
('Machine Learning', 'Introduction to machine learning techniques.', 2, NOW());


-- Assignments
INSERT INTO assignment (title, description, course_id, due_date, created_at) VALUES
('Write a C Program', 'Write a program to calculate factorial.', 1, '2024-12-15 23:59:59', NOW()),
('Linked List Problems', 'Solve linked list implementation problems.', 2, '2024-12-20 23:59:59', NOW()),
('SQL Queries', 'Write SQL queries for database operations.', 3, '2024-12-18 23:59:59', NOW()),
('Portfolio Website', 'Design a portfolio website.', 4, '2024-12-25 23:59:59', NOW()),
('Linear Regression', 'Implement linear regression in Python.', 5, '2024-12-30 23:59:59', NOW());

-- Enrollments
INSERT INTO enrollment (course_id, student_id, enrolled_at) VALUES
(1, 4, NOW()), (1, 5, NOW()), (2, 6, NOW()),
(3, 7, NOW()), (4, 8, NOW()), (5, 4, NOW()),
(1, 6, NOW()), (2, 8, NOW()), (3, 5, NOW()),
(4, 7, NOW()), (5, 6, NOW());


-- Submissions
INSERT INTO submission (assignment_id, student_id, submission_date, status) VALUES
(1, 4, '2024-12-14 15:30:00', 'SUBMITTED'),
(2, 6, '2024-12-19 18:45:00', 'SUBMITTED'),
(3, 7, '2024-12-17 10:00:00', 'SUBMITTED'),
(4, 8, '2024-12-24 12:00:00', 'PENDING'),
(5, 4, NULL, 'PENDING');
